require("./bootstrap");

// React Components
const root = ReactDOM.createRoot(document.getElementById("hello-react"));
const element = <h1>Hello, world</h1>;
root.render(element);
